#!/usr/bin/env node
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const archiver = require("archiver");
const dotenv = __importStar(require("dotenv"));
const promptSync = require("prompt-sync");
const axios_1 = __importDefault(require("axios"));
const prompt = promptSync();
dotenv.config();
// http://map-storage.workadventure.localhost/upload
// Fonction pour créer le dossier zip
function createZipDirectory(sourceDir, outPath) {
    return __awaiter(this, void 0, void 0, function* () {
        const archive = archiver('zip', { zlib: { level: 9 } });
        const stream = fs.createWriteStream(outPath);
        return new Promise((resolve, reject) => {
            archive
                .directory(sourceDir, false)
                .on('error', err => reject(err))
                .pipe(stream);
            stream.on('close', () => resolve());
            archive.finalize();
        });
    });
}
// Fonction pour vérifier l'URL du map storage
function checkMapStorageUrl(urlMapStorage) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let testUrl = `${urlMapStorage.replace('/upload', '/ping')}`;
            const response = yield axios_1.default.get(`${testUrl}`);
            console.log('Your map storage URL is :', urlMapStorage);
            return response.status === 200;
        }
        catch (err) {
            console.log(err);
            if (err.response && err.response.status === 401) {
                console.log('Invalid URL. Please provide a valid URL.');
            }
            else if (err.response && err.response.status === 403) {
                console.log('Forbidden access. Please provide a valid API Key.');
            }
            else if (err.response && err.response.status === 404) {
                console.log('Invalid URL. Please provide a valid URL.');
            }
            else {
                console.log("An error occurred while checking the URL. Please provide a valid URL.");
            }
            return false;
        }
    });
}
// Test pour demander des questions plus facilement
function askQuestions() {
    return __awaiter(this, void 0, void 0, function* () {
        let linkForMapStorageDocumentation = 'https://github.com/workadventure/workadventure/blob/develop/map-storage/README.md';
        let linkForMapStorageInfo = 'https://docs.workadventu.re/map-building/tiled-editor/';
        let apiKey;
        let uploadMode;
        let urlMapStorage;
        let directory;
        if (process.env.URL_MAP_STORAGE) {
            urlMapStorage = process.env.URL_MAP_STORAGE;
            console.log("URL Map Storage found in .env file, you're good to go !");
        }
        else {
            console.log(`Now let's set up your map storage URL. If you don't know you can see more details to find it here : ${linkForMapStorageDocumentation}\nand here ${linkForMapStorageInfo} !`);
            console.log("------------------------------------");
            while (!urlMapStorage || urlMapStorage === undefined || urlMapStorage === '' || urlMapStorage === ' ') {
                urlMapStorage = prompt(`Please enter your URL : `);
                console.log('A URL is required to upload your map');
                console.log('-------------------------------------');
                if (urlMapStorage && urlMapStorage !== ' ' && urlMapStorage !== undefined) {
                    ;
                    if (yield checkMapStorageUrl(urlMapStorage)) {
                        console.log('Map storage URL is valid.');
                    }
                    else {
                        console.log("------------------------------------");
                        urlMapStorage = '';
                    }
                }
            }
        }
        console.log("------------------------------------");
        const secretEnvPath = '.env.secret';
        if (fs.existsSync(secretEnvPath)) {
            console.log("SECRET ENV FILE FOUND!");
            if (fs.readFileSync(secretEnvPath).includes('API_KEY')) {
                console.log("SECRET ENV FILE FOUND AND NOT EMPTY!");
                const secretEnvContent = fs.readFileSync(secretEnvPath, 'utf8');
                const apiKeyMatch = secretEnvContent.match(/API_KEY=(.+)/);
                if (apiKeyMatch && apiKeyMatch[1]) {
                    apiKey = apiKeyMatch[1];
                    console.log("API Key found in .env.secret file, you're good to go !");
                }
            }
            else {
                console.log("SECRET ENV FILE FOUND BUT EMPTY!");
                while (apiKey === '' || !apiKey || apiKey === undefined || apiKey === ' ') {
                    apiKey = prompt('Please enter your API Key ?');
                    if (apiKey)
                        console.log('Your API Key is :', apiKey);
                    console.log("------------------------------------");
                }
            }
        }
        else {
            console.log("SECRET ENV FILE NOT FOUND!");
            while (apiKey === '' || !apiKey || apiKey === undefined || apiKey === ' ') {
                apiKey = prompt('Please enter your API Key ?');
                if (apiKey)
                    console.log('Your API Key is :', apiKey);
            }
        }
        if (process.env.DIRECTORY) {
            directory = process.env.DIRECTORY;
            console.log("Directory found in .env file, you're good to go !");
            console.log("------------------------------------");
        }
        else {
            if (!directory || directory === undefined) {
                console.log("------------------------------------");
                directory = prompt('Name of directory ? If null it will be call by default map-user :');
                if (directory) {
                    console.log('Your map will be in the directory :', directory);
                    console.log("------------------------------------");
                }
                else {
                    directory = 'map-user';
                    console.log('Your map will be in the directory :', directory);
                    console.log("------------------------------------");
                }
            }
        }
        if (process.env.UPLOAD_MODE === 'MAP_STORAGE') {
            uploadMode = process.env.UPLOAD_MODE;
            console.log("Your upload mode is : ", uploadMode);
        }
        else {
            uploadMode = 'MAP_STORAGE';
        }
        return { apiKey, directory, urlMapStorage, uploadMode };
    });
}
// Fonction pour effectuer l'upload avec axios
function uploadMap(apiKey, urlMapStorage, directory, uploadMode) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log("Uploading ...");
        yield axios_1.default.post(urlMapStorage, {
            apiKey: apiKey,
            file: fs.createReadStream('dist.zip'),
            directory: directory
        }, {
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'multipart/form-data'
            }
        });
        setTimeout(() => {
            console.log('Upload done successfully');
        }, 2000);
        if (!fs.existsSync('.env')) {
            console.log("Creating .env file...");
        }
        createEnvsFiles(apiKey, urlMapStorage, directory, uploadMode);
    });
}
// Fonction pour créer le fichier .env
function createEnvsFiles(apiKey, urlMapStorage, directory, uploadMode) {
    if (!fs.existsSync('.env') || fs.readFileSync('.env').length === 0) {
        fs.writeFileSync('.env', `LOG_LEVEL=1\nTILESET_OPTIMIZATION=false\nTILESET_OPTIMIZATION_QUALITY_MIN=0.9\nTILESET_OPTIMIZATION_QUALITY_MAX=1.0\nURL_MAP_STORAGE=${urlMapStorage}\nDIRECTORY=${directory}\nUPLOAD_MODE=${uploadMode}`);
        console.log('Env file created successfully');
        if (process.env.API_KEY) {
            fs.writeFileSync('.env', `LOG_LEVEL=1\nTILESET_OPTIMIZATION=false\nTILESET_OPTIMIZATION_QUALITY_MIN=0.9\nTILESET_OPTIMIZATION_QUALITY_MAX=1.0\nURL_MAP_STORAGE=${urlMapStorage}\nDIRECTORY=${directory}\nUPLOAD_MODE=${uploadMode}`);
            delete process.env.API_KEY;
        }
    }
    if (!fs.existsSync('.env.secret') || !fs.readFileSync('.env.secret').includes(apiKey)) {
        fs.writeFileSync('.env.secret', `API_KEY=${apiKey}`);
        console.log('API Key added to the .env file');
    }
    if (process.env.API_KEY) {
        delete process.env.API_KEY;
        fs.writeFileSync('.env', `LOG_LEVEL=1\nTILESET_OPTIMIZATION=false\nTILESET_OPTIMIZATION_QUALITY_MIN=0.9\nTILESET_OPTIMIZATION_QUALITY_MAX=1.0\nURL_MAP_STORAGE=${urlMapStorage}\nDIRECTORY=${directory}\nUPLOAD_MODE=${uploadMode}`);
    }
    if (fs.existsSync('.env')) {
        fs.writeFileSync('.env', `LOG_LEVEL=1\nTILESET_OPTIMIZATION=false\nTILESET_OPTIMIZATION_QUALITY_MIN=0.9\nTILESET_OPTIMIZATION_QUALITY_MAX=1.0\nURL_MAP_STORAGE=${urlMapStorage}\nDIRECTORY=${directory}\nUPLOAD_MODE=${uploadMode}`);
    }
}
// Fonction principale
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Créer le dossier zip
            const sourceDirectory = 'dist';
            const finalDirectory = 'dist.zip';
            yield createZipDirectory(sourceDirectory, finalDirectory);
            console.log('Directory has been zipped');
            console.log("------------------------------------");
            // Demander des informations à l'utilisateur
            const { apiKey, directory, urlMapStorage, uploadMode } = yield askQuestions();
            // Envoyer l'upload
            if (apiKey && urlMapStorage && (directory !== null && directory !== void 0 ? directory : '') && uploadMode || process.env.URL_MAPSTORAGE && process.env.API_KEY && process.env.DIRECTORY && process.env.UPLOAD_MODE) {
                yield uploadMap(apiKey, urlMapStorage, directory !== null && directory !== void 0 ? directory : '', uploadMode);
            }
        }
        catch (err) {
            console.error('ERROR DE OUF :', err);
        }
    });
}
main();
//# sourceMappingURL=upload.js.map