#!/usr/bin/env node
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const archiver = require("archiver");
const dotenv = __importStar(require("dotenv"));
const promptSync = require("prompt-sync");
const axios_1 = __importDefault(require("axios"));
const yargs = require("yargs");
const prompt = promptSync();
dotenv.config();
let apiKeyFilledInUpload = false;
let variableEnv = false;
// Function to create the zip folder
async function createZipDirectory(sourceDir, outPath) {
    const archive = archiver("zip", { zlib: { level: 9 } });
    const stream = fs.createWriteStream(outPath);
    return new Promise((resolve, reject) => {
        archive
            .directory(sourceDir, false)
            .on("error", (err) => reject(err))
            .pipe(stream);
        stream.on("close", () => resolve());
        archive.finalize();
    });
}
// Function to check map storage URL
async function checkMapStorageUrl(mapStorageUrl) {
    if (mapStorageUrl !== "/upload" &&
        mapStorageUrl !== undefined &&
        mapStorageUrl !== " /upload" &&
        mapStorageUrl !== null) {
        try {
            const testUrl = `${mapStorageUrl.replace("/upload", "/ping")}`;
            console.log("test URL :", testUrl);
            const response = await axios_1.default.get(`${testUrl}`);
            console.log("Your map storage URL is :", mapStorageUrl);
            return response.status === 200;
        }
        catch (err) {
            console.log(err);
            if (err.response && err.response.status === 401) {
                console.log("Invalid URL. Please provide a valid URL.");
            }
            else if (err.response && err.response.status === 403) {
                console.log("Forbidden access. Please provide a valid API Key.");
            }
            else if (err.response && err.response.status === 404) {
                console.log("Invalid URL. Please provide a valid URL.");
            }
            else {
                console.log("An error occurred while checking the URL. Please provide a valid URL.");
            }
            return false;
        }
    }
    else {
        console.log("Please provide a valid URL.");
        return false;
    }
}
// Ask input for users
async function askQuestions() {
    const linkForMapStorageDocumentation = "https://github.com/workadventure/workadventure/blob/develop/map-storage/README.md";
    const linkForMapStorageInfo = "https://docs.workadventu.re/map-building/tiled-editor/";
    const argv = yargs
        .option("apiKey", {
        alias: "k",
        describe: "API Key for the script",
        demandOption: false, // Indique si l'option est obligatoire
        type: "string" // Type de la valeur de l'option
    })
        .option("directory", {
        alias: "d",
        describe: "Directory for the script",
        demandOption: false,
        type: "string"
    })
        .option("uploadMode", {
        alias: "u",
        describe: "Upload mode for the script",
        demandOption: false,
        type: "string"
    })
        .option("mapStorageUrl", {
        alias: "m",
        describe: "Map Storage Url for the script",
        demandOption: false,
        type: "string"
    })
        .help()
        .argv;
    console.log(argv);
    let mapStorageApiKey;
    let uploadMode = process.env.UPLOAD_MODE || (await argv).uploadMode;
    let mapStorageUrl = process.env.MAP_STORAGE || (await argv).mapStorageUrl || undefined;
    // let directory = process.env.MAP_STORAGE || (await argv).directory || undefined;
    let directory = (await argv).directory || process.env.DIRECTORY;
    if (process.env.URL_MAP_STORAGE) {
        mapStorageUrl = process.env.URL_MAP_STORAGE;
        console.log("URL Map Storage found, you're good to go !");
    }
    else {
        console.log(`Now let's set up your map storage URL. If you don't know you can see more details to find it here : ${linkForMapStorageDocumentation}\nand here ${linkForMapStorageInfo} !`);
        console.log("------------------------------------");
        while (!mapStorageUrl || mapStorageUrl === undefined || mapStorageUrl === "" || mapStorageUrl === " ") {
            mapStorageUrl = prompt(`Please enter your URL : `);
            mapStorageUrl = mapStorageUrl.concat("/upload");
            console.log("A URL is required to upload your map");
            console.log("-------------------------------------");
            if (mapStorageUrl && mapStorageUrl !== " " && mapStorageUrl !== undefined) {
                if (await checkMapStorageUrl(mapStorageUrl)) {
                    variableEnv = true;
                    console.log("Map storage URL is valid.");
                }
                else {
                    console.log("------------------------------------");
                    mapStorageUrl = "";
                }
            }
        }
    }
    console.log("------------------------------------");
    dotenv.config({ path: ".env.secret" });
    if (process.env.API_KEY) {
        mapStorageApiKey = process.env.API_KEY;
        console.log("Secret env found and not empty!");
    }
    else {
        console.log("Secret env found but empty!");
        while (mapStorageApiKey === "" ||
            !mapStorageApiKey ||
            mapStorageApiKey === undefined ||
            mapStorageApiKey === " ") {
            mapStorageApiKey = prompt("Please enter your API Key ?");
            if (mapStorageApiKey) {
                console.log("Your API Key is :", mapStorageApiKey);
                console.log("------------------------------------");
                apiKeyFilledInUpload = true;
            }
        }
    }
    if (directory !== (await argv).directory || directory !== process.env.DIRECTORY) {
        console.log(directory);
        console.log("------------------------------------");
        directory = prompt("Name of directory ? (optional)");
        if (directory) {
            variableEnv = true;
            console.log("Your map will be in the directory :", directory);
            console.log("------------------------------------");
        }
        else {
            console.log("NO DIRECTORY");
            directory = undefined;
        }
    }
    else {
        directory = (await argv).directory || process.env.DIRECTORY;
    }
    // if (process.env.DIRECTORY) {
    //     directory = process.env.DIRECTORY;
    //     console.log("Directory found in .env file, you're good to go !");
    //     console.log("------------------------------------");
    // } else {
    //     console.log("------------------------------------");
    //     directory = prompt("Name of directory ? (optional)");
    //     if (directory) {
    //         variableEnv = true;
    //         console.log("Your map will be in the directory :", directory);
    //         console.log("------------------------------------");
    //     } else {
    //         console.log("NO DIRECTORY");
    //         directory = undefined;
    //     }
    // }
    if (uploadMode) {
        console.log("bonjour je suis dans le argv");
        uploadMode = "MAP_STORAGE";
        console.log(uploadMode);
    }
    else {
        console.log(uploadMode);
        console.log("AU REVOIR");
    }
    // if (uploadMode !== (await argv).uploadMode || uploadMode !== process.env.UPLOAD_MODE) {
    //     console.log("BONJOUR")
    //     console.log(uploadMode)
    // } else {
    //     console.log(uploadMode)
    //     console.log("AU REVOIR")
    // }
    // if (process.env.UPLOAD_MODE) {
    //     uploadMode = process.env.UPLOAD_MODE;
    //     console.log("Your upload mode is : ", uploadMode);
    //     variableEnv = true;
    // } else {
    //     uploadMode = "MAP_STORAGE";
    //     variableEnv = true;
    // }
    return { mapStorageApiKey, directory, mapStorageUrl, uploadMode };
}
// Upload function with axios
async function uploadMap(mapStorageApiKey, mapStorageUrl, directory = null, uploadMode) {
    console.log("Uploading ...");
    await axios_1.default.post(mapStorageUrl, {
        apiKey: mapStorageApiKey,
        file: fs.createReadStream("dist.zip"),
        directory: directory,
    }, {
        headers: {
            Authorization: `Bearer ${mapStorageApiKey}`,
            "Content-Type": "multipart/form-data",
        },
    });
    setTimeout(() => {
        console.log("Upload done successfully");
    }, 2000);
    if (!fs.existsSync(".env")) {
        console.log("Creating .env file...");
        createEnvsFiles(mapStorageApiKey, mapStorageUrl, directory, uploadMode);
    }
    if (apiKeyFilledInUpload || variableEnv) {
        createEnvsFiles(mapStorageApiKey, mapStorageUrl, directory, uploadMode);
    }
}
// Function to create the .env files
function createEnvsFiles(mapStorageApiKey, mapStorageUrl, directory, uploadMode) {
    if (!fs.existsSync(".env") || fs.readFileSync(".env").length === 0 || variableEnv) {
        fs.writeFileSync(".env", `LOG_LEVEL=1\nTILESET_OPTIMIZATION=false\nTILESET_OPTIMIZATION_QUALITY_MIN=0.9\nTILESET_OPTIMIZATION_QUALITY_MAX=1.0\nURL_MAP_STORAGE=${mapStorageUrl}\nDIRECTORY=${directory}\nUPLOAD_MODE=${uploadMode}`);
        console.log("Env files created successfully");
        if (process.env.API_KEY) {
            delete process.env.API_KEY;
        }
    }
    if (!fs.existsSync(".env.secret") || !fs.readFileSync(".env.secret").includes(mapStorageApiKey)) {
        fs.writeFileSync(".env.secret", `API_KEY=${mapStorageApiKey}`);
        console.log("API Key added to the .env file");
    }
}
// Fonction for upload
async function main() {
    try {
        // Create zip file
        const sourceDirectory = "dist";
        const finalDirectory = "dist.zip";
        await createZipDirectory(sourceDirectory, finalDirectory);
        console.log("Directory has been zipped");
        console.log("------------------------------------");
        // Ask user input
        const { mapStorageApiKey, directory, mapStorageUrl, uploadMode } = await askQuestions();
        // Send upload
        if ((mapStorageApiKey && mapStorageUrl && uploadMode) ||
            (process.env.URL_MAPSTORAGE && process.env.API_KEY && process.env.UPLOAD_MODE)) {
            if (directory) {
                await uploadMap(mapStorageApiKey, mapStorageUrl, directory, uploadMode);
            }
            else {
                await uploadMap(mapStorageApiKey, mapStorageUrl, null, uploadMode);
            }
        }
    }
    catch (err) {
        console.error("ERROR :", err);
    }
}
main();
//# sourceMappingURL=upload.js.map